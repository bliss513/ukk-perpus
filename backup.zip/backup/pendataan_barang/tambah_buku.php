<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $sampul = $_FILES['sampul']['name'];
    $tmp_name = $_FILES['sampul']['tmp_name'];
    $target_dir = '../uploads';

    // Cegah duplikasi nama file dengan menambahkan timestamp
    $unique_filename = time() . '_' . basename($sampul);
    $target_file = $target_dir . $unique_filename;

    // Validasi apakah file berhasil di-upload
    if (move_uploaded_file($tmp_name, $target_file)) {
        $sql = "INSERT INTO buku (judul, penulis, penerbit, tahun_terbit, sampul) 
                VALUES ('$judul', '$penulis', '$penerbit', '$tahun_terbit', '$unique_filename')";
        
        if ($conn->query($sql) === TRUE) {
            header('Location: daftar_buku.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Gagal mengunggah file.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Buku</title>
</head>
<body>
    <h2>Tambah Buku</h2>
    <form method="POST" enctype="multipart/form-data">
        Judul: <input type="text" name="judul" required><br>
        Penulis: <input type="text" name="penulis" required><br>
        Penerbit: <input type="text" name="penerbit" required><br>
        Tahun Terbit: <input type="number" name="tahun_terbit" required><br>
        Sampul: <input type="file" name="sampul" accept="image/*" required><br>
        <button type="submit" name="submit">Tambah</button>
    </form>
    <a href="daftar_buku.php">Kembali ke Daftar Buku</a>
</body>
</html>
