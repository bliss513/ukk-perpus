<?php
include 'koneksi.php';

if (isset($_POST['id'], $_POST['field'], $_POST['value'])) {
    $id = intval($_POST['id']);
    $field = $_POST['field'];
    $value = $conn->real_escape_string($_POST['value']);

    if (in_array($field, ['judul', 'penulis', 'penerbit', 'tahun_terbit'])) {
        $sql = "UPDATE buku SET $field = '$value' WHERE buku_id = $id";
        if ($conn->query($sql) === TRUE) {
            echo 'Sukses';
        } else {
            http_response_code(500);
            echo 'Gagal';
        }
    }
}
?>
