<?php
include 'koneksi.php';
$result = $conn->query("SELECT * FROM buku");
?>

<!DOCTYPE html>
<html>
<head>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    color: #333;
    display: flex;
}


.content {
    margin-left: 220px;
    padding: 20px;
    width: calc(100% - 220px);
}

.content h2 {
    margin-bottom: 20px;
    color: #333;
}

.content a {
    display: inline-block;
    margin-bottom: 20px;
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.content a:hover {
    background-color: #45a049;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table th, table td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}

table th {
    background-color: #333;
    color: white;
}

table td img {
    border-radius: 5px;
}

table tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tr:hover {
    background-color: #f1f1f1;
}

a {
    color: #4CAF50;
    text-decoration: none;
}

a:hover {
    color:rgb(4, 94, 25);
}
</style>

    <title>Daftar Buku</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function makeEditable(td, id, field) {
            const oldValue = td.innerText;
            td.innerHTML = `<input type='text' value='${oldValue}' onblur='saveEdit(this, ${id}, "${field}")'>`;
            td.firstChild.focus();
        }

        function saveEdit(input, id, field) {
            const newValue = input.value;
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'update_buku.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    input.parentElement.innerText = newValue;
                } else {
                    alert('Gagal menyimpan perubahan');
                }
            };
            xhr.send(`id=${id}&field=${field}&value=${newValue}`);
        }
    </script>
</head>
<body>
    <?php 
    include 'sidebar.php' 
    ?>

    <div class="content">
        <h2>Daftar Buku</h2>
        <a href="tambah_buku.php">Tambah Buku</a>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Cover</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tahun Terbit</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['buku_id']; ?></td>
                    <td><img src="../uploads<?php echo $row['sampul']; ?>" width="100" height="150"></td>
                    <td ondblclick="makeEditable(this, <?php echo $row['buku_id']; ?>, 'judul')"><?php echo $row['judul']; ?></td>
                    <td ondblclick="makeEditable(this, <?php echo $row['buku_id']; ?>, 'penulis')"><?php echo $row['penulis']; ?></td>
                    <td ondblclick="makeEditable(this, <?php echo $row['buku_id']; ?>, 'penerbit')"><?php echo $row['penerbit']; ?></td>
                    <td ondblclick="makeEditable(this, <?php echo $row['buku_id']; ?>, 'tahun_terbit')"><?php echo $row['tahun_terbit']; ?></td>
                    <td>
                        <a href="hapus_buku.php?id=<?php echo $row['buku_id']; ?>" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
