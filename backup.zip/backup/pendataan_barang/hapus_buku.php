<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM buku WHERE buku_id=$id";
    if ($conn->query($sql) === TRUE) {
        header('Location: daftar_buku.php');
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
