<style>
.sidebar {
    width: 200px;
    background-color: #333;
    color: white;
    padding: 20px;
    position: fixed;
    height: 100%;
}

.sidebar h3 {
    color:rgb(167, 155, 184);
    margin-bottom: 20px;
    text-align: center;
}

.sidebar ul {
    list-style-type: none;
}

.sidebar ul li {
    margin: 15px 0;
    text-align: center;
}

.sidebar ul li a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
}

.sidebar ul li a:hover {
    color: #f4f4f9;
}

</style>
<div class="sidebar">
        <h3>!APK ORANG! !GALAW!</h3>
        <ul>
        <li><a href="../dashboard.php">Dashboard</a></li>
            <li><a href="daftar_buku.php">Daftar Buku</a></li>
            <li><a href="../peminjaman.php">Peminjaman</a></li>
            <li><a href="#">Logout</a></li>
        </ul>
    </div>