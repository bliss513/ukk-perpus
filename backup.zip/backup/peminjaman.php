<?php
// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'perpustakaan_ukk');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk meminjam buku
if (isset($_POST['pinjam'])) {
    $user_id = $_POST['user_id'];
    $buku_id = $_POST['buku_id'];
    $tanggal_peminjaman = date('Y-m-d');

    $query = "INSERT INTO peminjaman (user_id, buku_id, tanggal_peminjaman, status_peminjaman) VALUES ('$user_id', '$buku_id', '$tanggal_peminjaman', 'dipinjam')";
    $conn->query($query);
}

// Fungsi untuk mengembalikan buku
if (isset($_POST['kembalikan'])) {
    $peminjaman_id = $_POST['peminjaman_id'];
    $query = "UPDATE peminjaman SET status_peminjaman = 'dikembalikan', tanggal_pengembalian = NOW() WHERE peminjaman_id = '$peminjaman_id' AND status_peminjaman = 'dipinjam'";
    $conn->query($query);
}

// Menampilkan data peminjaman
$query = "SELECT p.peminjaman_id, u.nama_lengkap AS nama_peminjam, b.judul, b.sampul, p.tanggal_peminjaman, p.tanggal_pengembalian, p.status_peminjaman 
          FROM peminjaman p 
          JOIN user u ON p.user_id = u.user_id 
          JOIN buku b ON p.buku_id = b.buku_id";
$result = $conn->query($query);

// Mengambil data user dan buku untuk form peminjaman
$users = $conn->query("SELECT user_id, nama_lengkap FROM user");
$buku = $conn->query("SELECT buku_id, judul FROM buku");
?>

<!DOCTYPE html>
<html lang="id">
<?php 
    include 'sidebar.php'
    ?>
<head>
    <meta charset="UTF-8">
    <title>Daftar Peminjaman Buku</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .content {
            margin-left: 220px;
            padding: 20px;
            width: calc(100% - 220px);
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            margin-bottom: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label, select, button {
            display: block;
            margin-bottom: 10px;
        }

        select, button {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            width: 50px;
            height: auto;
            border-radius: 5px;
        }
    </style>
</head>
<body>
   
<div class="content">
    <h2>Form Peminjaman Buku</h2>
    <form method="POST">
        <label>Nama Peminjam:</label>
        <select name="user_id" required>
            <option value="">Pilih Peminjam</option>
            <?php while ($user = $users->fetch_assoc()) { ?>
                <option value="<?= $user['user_id'] ?>"><?= $user['nama_lengkap'] ?></option>
            <?php } ?>
        </select>

        <label>Judul Buku:</label>
        <select name="buku_id" required>
            <option value="">Pilih Buku</option>
            <?php while ($bk = $buku->fetch_assoc()) { ?>
                <option value="<?= $bk['buku_id'] ?>"><?= $bk['judul'] ?></option>
            <?php } ?>
        </select>

        <button type="submit" name="pinjam">Pinjam Buku</button>
    </form>

    <h2>Daftar Peminjaman Buku</h2>
    <table>
        <tr>
            <th>ID Peminjaman</th>
            <th>Cover</th>
            <th>Nama Peminjam</th>
            <th>Judul Buku</th>
            <th>Tanggal Peminjaman</th>
            <th>Tanggal Pengembalian</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['peminjaman_id'] ?></td>
                <td><img src="uploads<?= $row['sampul']; ?>" width="100" height="150"></td>
                <td><?= $row['nama_peminjam'] ?></td>
                <td><?= $row['judul'] ?></td>
                <td><?= $row['tanggal_peminjaman'] ?></td>
                <td><?= $row['tanggal_pengembalian'] ?? '-' ?></td>
                <td><?= $row['status_peminjaman'] ?></td>
                <td>
                    <?php if ($row['status_peminjaman'] == 'dipinjam') { ?>
                        <form method="POST">
                            <input type="hidden" name="peminjaman_id" value="<?= $row['peminjaman_id'] ?>">
                            <button type="submit" name="kembalikan">Dikembalikan</button>
                        </form>
                    <?php } else { ?>
                        Sudah Dikembalikan
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>

<?php $conn->close(); ?>
