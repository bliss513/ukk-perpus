<?php
include 'koneksi.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $alamat = $_POST['alamat'];

    $sql = "INSERT INTO user (username, password, email, nama_lengkap, alamat) VALUES ('$username', '$password', '$email', '$nama_lengkap', '$alamat')";
    if ($conn->query($sql) === TRUE) {
        echo "Registrasi berhasil. <a href='index.php'>Login di sini</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrasi</title>
</head>
<body>
    <h2>Form Registrasi</h2>
    <form method="POST">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        Email: <input type="email" name="email" required><br>
        Nama Lengkap: <input type="text" name="nama_lengkap" required><br>
        Alamat: <textarea name="alamat" required></textarea><br>
        <button type="submit" name="register">Daftar</button>
    </form>
    <a href="login.php">Sudah punya akun? Login di sini</a>
</body>
</html>