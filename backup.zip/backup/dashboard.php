<?php
include 'koneksi.php';
$resultBuku = $conn->query("SELECT * FROM buku");
$resultPeminjaman = $conn->query("SELECT p.peminjaman_id, u.nama_lengkap AS nama_peminjam, b.judul, b.sampul, p.tanggal_peminjaman, p.tanggal_pengembalian, p.status_peminjaman FROM peminjaman p JOIN user u ON p.user_id = u.user_id JOIN buku b ON p.buku_id = b.buku_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Perpustakaan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; display: flex; }
        .sidebar { width: 220px; background-color: #333; color: white; padding: 20px; height: 100vh; position: fixed; }
        .sidebar a:hover { background-color: #444; }
        .content { margin-left: 240px; padding: 20px; background-color: #fff; width: calc(100% - 240px); }
        h2 { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #333; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #f1f1f1; }
        img { width: 50px; height: auto; }
    </style>
</head>
<body>
    <?php
    include 'sidebar.php'
    ?>
    <div class="content">
        <section id="buku">
            <h2>Daftar Buku</h2>
            <table>
                <tr><th>Judul</th><th>Penulis</th></tr>
                <?php while ($row = $resultBuku->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['judul'] ?></td>
                        <td><?= $row['penulis'] ?></td>
                    </tr>
                <?php } ?>
            </table>
        </section>

        <section id="peminjaman">
            <h2>Daftar Peminjaman Buku</h2>
            <table>
                <tr><th>ID Peminjaman</th><th>Nama Peminjam</th><th>Judul Buku</th><th>Tanggal Peminjaman</th><th>Tanggal Pengembalian</th><th>Status</th></tr>
                <?php while ($row = $resultPeminjaman->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['peminjaman_id'] ?></td>
                        <td><?= $row['nama_peminjam'] ?></td>
                        <td><?= $row['judul'] ?></td>
                        <td><?= $row['tanggal_peminjaman'] ?></td>
                        <td><?= $row['tanggal_pengembalian'] ?></td>
                        <td><?= $row['status_peminjaman'] ?></td>
                    </tr>
                <?php } ?>
            </table>
        </section>
    </div>
</body>
</html>
<?php $conn->close(); ?>